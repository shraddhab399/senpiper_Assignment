package com.example.liv2train;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Liv2trainApplicationTests {

	@Test
	void contextLoads() {
	}

}
